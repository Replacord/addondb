
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.trophys.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.trophys.item.TnormItem;
import net.mcreator.trophys.item.Tnorm3dItem;
import net.mcreator.trophys.TrophysMod;

public class TrophysModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TrophysMod.MODID);
	public static final RegistryObject<Item> TNORM = REGISTRY.register("tnorm", () -> new TnormItem());
	public static final RegistryObject<Item> TNORM_3D = REGISTRY.register("tnorm_3d", () -> new Tnorm3dItem());
}
